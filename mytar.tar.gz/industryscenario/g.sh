#!/bin/bash
for test in $(cat $1)
do
groupadd $test
done

