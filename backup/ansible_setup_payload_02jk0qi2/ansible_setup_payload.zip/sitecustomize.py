import sys
sys.path.insert(0,"/tmp/ansible_setup_payload_02jk0qi2/ansible_setup_payload.zip")
